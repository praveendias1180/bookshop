function button_clicked(){
    alert("This website is a part of an assignment!")
}